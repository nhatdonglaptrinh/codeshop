<?php
require("TMQ/function.php");
require("TMQ/head.php");
?>
<div class="c-layout-page">

 <!-- END: HEADER -->
    <!-- END: LAYOUT/HEADERS/HEADER-1 --><link href="//www.nimo.tv/nms/home.act.daily_lottery.20148b6987fa11287d75.css" rel="stylesheet">
<script charset="utf-8" src="https://www.nimo.tv/nms/9efaf.497abcdba3b15f6224dc.js"></script>
<script charset="utf-8" src="https://www.nimo.tv/nms/c41fc.6c5606ce4333fb561caa.js"></script>
<script charset="utf-8" src="https://www.nimo.tv/nms/c9083.371a61ec7f7df63e6ab3.js"></script>
<link rel="stylesheet" type="text/css" href="https://www.nimo.tv/nms/NimoCommonHeader.d287129e55a4e7f21b24.css">
<script charset="utf-8" src="https://www.nimo.tv/nms/NimoCommonHeader.fb5b24029b669f873034.js"></script>
<script charset="utf-8" src="https://www.nimo.tv/nms/9b28c.361ad08a7861a4066c20.js"></script>

<div id="main" class="n-as-rel n-as-z0" style="margin-top:0px">
 

	<div class="nimo-daily-lottery">
		<div class="nimo-daily-lottery_header">
			<div class="nimo-daily-lottery_banner">
			</div>
			<div class="nimo-daily-lottery_banner-circle">
			</div>
		</div>
		<div class="nimo-daily-lottery_body">
			<div class="nimo-daily-lottery_plane">
				<div class="nimo-daily-lottery_plane-header">
					<div class="nimo-daily-lottery_plane-title">
						<div class="nimo-daily-lottery_plane-title-text">Số tiền hiện còn:<em><?php echo number_format($TMQ[cash]);?><sup>VNĐ</sup></em>
						</div>
					</div>
					<div class="nimo-daily-lottery_plane-light">
						<div class="nimo-daily-lottery_plane-light-sm">
						</div>
						<div class="nimo-daily-lottery_plane-light-lg">
						</div>
						<div class="nimo-daily-lottery_plane-light-sm">
						</div>
					</div>
				</div>
				<span>
				<div class="nimo-daily-lottery_plane-body">
					<div class="nimo-daily-lottery_plane-body-inner">
						<div class="components_dailyLottery_desktop">
							<div class="components_DailyLottery_Plane_Main">
								<div class="components_dailyLotteryPlane">
									<div class="list_container">
										<div class="list_item item1">
											<div class="imgContainer">
												<img alt="Nimo TV" src="/kimhung/diamond.png">
											</div>
											<div class="title"> 5000 Kim Cương</div>
										</div>
										<div class="list_item item2">
											<div class="imgContainer">
												<img alt="Nimo TV" src="https://zingplay.static.g6.zing.vn//images/data/q6.png">
											</div>
											<div class="title"> Trật Rồi</div>
										</div>
										<div class="list_item item3">
											<div class="imgContainer">
												<img alt="Nimo TV" src="/kimhung/diamond.png">
											</div>
											<div class="title"> 80 Kim Cương</div>
										</div>
										<div class="list_item item4">
											<div class="imgContainer">
												<img alt="Nimo TV" src="/kimhung/diamond.png">
											</div>
											<div class="title"> 150 Kim Cương</div>
										</div>
										<div class="list_item item5">
											<div class="imgContainer">
												<img alt="Nimo TV" src="/kimhung/diamond.png">
											</div>
											<div class="title"> 250 Kim Cương</div>
										</div>
										<div class="list_item item6">
											<div class="imgContainer">
												<img alt="Nimo TV" src="/kimhung/diamond.png">
											</div>
											<div class="title"> 1000 Kim Cương</div>
										</div>
										<div class="list_item item7">
											<div class="imgContainer">
												<img alt="Nimo TV" src="/kimhung/diamond.png">
											</div>
											<div class="title"> 1500 Kim Cương</div>
										</div>
										<div class="list_item item8">
											<div class="imgContainer">
												<img alt="Nimo TV" src="/kimhung/diamond.png">
											</div>
											<div class="title"> 3000 Kim Cương</div>
										</div>
										<div class="btn" id="quay">
											<div class="goBtn">
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div></span>
					<div class="nimo-daily-lottery_plane-lantern nimo-daily-lottery_plane-lantern-left">
						<span class="nimo-daily-lottery_plane-lantern_item">
						</span>
						<span class="nimo-daily-lottery_plane-lantern_item">
						</span>
						<span class="nimo-daily-lottery_plane-lantern_item">
						</span>
						<span class="nimo-daily-lottery_plane-lantern_item">
						</span>
						<span class="nimo-daily-lottery_plane-lantern_item">
						</span>
					</div>
					<div class="nimo-daily-lottery_plane-lantern nimo-daily-lottery_plane-lantern-right">
						<span class="nimo-daily-lottery_plane-lantern_item">
						</span>
						<span class="nimo-daily-lottery_plane-lantern_item">
						</span>
						<span class="nimo-daily-lottery_plane-lantern_item">
						</span>
						<span class="nimo-daily-lottery_plane-lantern_item">
						</span>
						<span class="nimo-daily-lottery_plane-lantern_item">
						</span>
					</div>
					<div class="nimo-daily-lottery_plane-body-shadow left">
					</div>
					<div class="nimo-daily-lottery_plane-body-shadow right">
					</div>
				</div>
				<div class="nimo-daily-lottery_plane-footer">
					<div class="nimo-daily-lottery_plane-spaceship">
					</div>
					<div class="nimo-daily-lottery_plane-footer-mask">
					</div>
				</div>
				<div class="nimo-daily-lottery_plane-shadow">
				</div>
			</div>
			<div class="nimo-daily-lottery_right">
				<div class="nimo-daily-lottery_lamp">
					<div class="nimo-daily-lottery_lamp-title">
						<div class="nimo-daily-lottery_lamp-title-bg">
							<div class="nimo-daily-lottery_lamp-title-bg-line">
							</div>
							<div class="nimo-daily-lottery_lamp-title-bg-line">
							</div>
							<div class="nimo-daily-lottery_lamp-title-bg-line">
							</div>
							<div class="nimo-daily-lottery_lamp-title-bg-line">
							</div>
							<div class="nimo-daily-lottery_lamp-title-bg-line">
							</div>
							<div class="nimo-daily-lottery_lamp-title-bg-line">
							</div>
						</div>
						<span class="nimo-daily-lottery_lamp-title-text">
							<i class="nimo-icon nimo-icon-trumpet">
							</i>
							<span>Lượt Quay Gần Đây</span>
						</span>
					</div>
					<div class="nimo-daily-lottery_lamp-body">
						<div class="components_DailyLottery_client">
							<div class="components_DailyLottery_Lamp_main">
								<div class="components_DayilLottery_Lamp">
									<div class="Lamp_ListContainer" style="transform: translate3d(0px, -245.455px, 0px);">

                                    
<?php
$get = $db->query("SELECT * FROM `HK_quayff` WHERE `kimcuong` != '0' ORDER BY id DESC LIMIT 0,20");
if($get != null){
foreach($get as $ls){
?>			

<li class="ListContainer_item">
											<div class="nimo-daily-lottery_lamp-item">
											    Chúc mừng <em class="nimo-daily-lottery_lamp-item-nickname"><?= str_replace( substr(($ls['nguoiquay']), -3), '***', ($ls['nguoiquay']) );?></em>
											    đã nhận được  <em class="nimo-daily-lottery_lamp-item-prize"><?=number_format($ls['kimcuong']);?> Kim cương</em>
											</div>
										</li>
<?php }
 }else{?>
   <li class="ListContainer_item">
											<div class="nimo-daily-lottery_lamp-item">
											    Không có lượt quay nào gần đây.
											</div>
										</li>
<?
 } ?>

										 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="nimo-daily-lottery_wallet">
					<div class="nimo-daily-lottery_wallet-title">Lucky Draw Record</div>
					<div class="nimo-daily-lottery_wallet-body">
						<div class="nimo-daily-lottery_wallet-balance">
							<!--<div class="nimo-daily-lottery_wallet-diamond">-->
							<!--	<i>-->
							<!--	</i>0</div>-->
								<div class="nimo-daily-lottery_wallet-coin">
									<img src="/kimhung/diamond.png" width="25px"/>
																	</div>
									
								</div>
								<div class="nimo-daily-lottery_wallet-btn">Lucky Draw Record</div>
							</div>
						</div>
						<div class="nimo-daily-lottery_rules">
							<div role="main" class="container mceEditable" data-slot="default" style="height: 260px;width: 400px;padding: 10px;-webkit-box-sizing: border-box;-moz-box-sizing: border-box;box-sizing: border-box;overflow: hidden;border: 2px dashed #fff;-webkit-border-radius: 8px;-moz-border-radius: 8px;border-radius: 8px;color: #fff;">
                                <p class="ql-long-4888981"><span style="color: #ffffff;">Vòng quay may mắn</span></p>
                                <p class="ql-long-4888981"><span style="color: #ffffff;">1.Kim cương bốc ở shop là hoàn toàn kim cương sạch do garena.vn cung cấp và không phải kim cương lậu </span></p>
                                <p class="ql-long-4888981"><span style="color: #ffffff;">2.Mỗi lượt quay bạn cần trả 17K cho 1 lần bốc </span></p>
                                <p class="ql-long-4888981"><span style="color: #ffffff;">3.Quy đổi kim cương ở mục Rút Kim Cương ở trên menu thành viên trong shop </span></p>
                                <p class="ql-long-4888981"><span style="color: #ffffff;">4.Đây là 1 vòng quay được liên kết cùng với vòng quay mùa hè 17K! </span></p>
                                <p class="ql-long-4888981"><span style="color: #ffffff;">5.Cảm ơn các bạn đã luôn đồng hành cùng chúng tôi! </span></p>
                            </div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div tabindex="-1" class="nimo-modal-wrap nimo-modal-centered" id="nhanqua" style="display:none" role="dialog">
	<div role="document" class="nimo-modal nimo-confirm nimo-confirm-info nimo-daily-lottery_modal nimo-daily-lottery_modal-won" style="width: 416px;">
		<div tabindex="0" style="width: 0px; height: 0px; overflow: hidden;">sentinelStart</div>
		<div class="nimo-modal-content bc1 bsc3">
			<button aria-label="Close" class="nimo-modal-close">
				<span class="nimo-modal-close-x c3">
				</span>
			</button>
			<div class="nimo-modal-body n-as-scroll">
				<div class="nimo-confirm-body-wrapper">
					<div class="nimo-confirm-body">
						<div class="nimo-confirm-content">
							<div class="nimo-daily-lottery_modal-won-prize">
								<div class="nimo-daily-lottery_modal-won-prize-icon">
									<span class="nimo-image nimo-avatar nimo-avatar-lg nimo-avatar-square nimo-avatar-image">
										<picture>
											<source srcset="upload/images/49778652_1954671194840674_6919213934721368064_n.png" type="image/webp">
												<img src="/kimhung/diamond.png" alt="Nimo TV">
											</picture>
										</span>
									</div>
									<div class="nimo-daily-lottery_modal-won-prize-divider">
									</div>
									<div class="nimo-daily-lottery_modal-won-prize-text">
										<div class="nimo-daily-lottery_modal-won-prize-title">Chúc mừng</div>
										<div class="nimo-daily-lottery_modal-won-prize-content">bạn đã nhận được <span id="gift"></span></div>
									</div>
								</div>
							</div>
						</div>
						<div class="nimo-confirm-btns">
							<button type="button" class="nimo-btn nimo-btn-secondary nimo-btn-lg">
								<span>Got it!</span>
							</button>
						</div>
					</div>
				</div>
			</div>
			<div tabindex="0" style="width: 0px; height: 0px; overflow: hidden;">sentinelEnd</div>
		</div>
	</div>
	<div class="modal fade" id="noticeModal" role="dialog" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
<h4 class="modal-title" style="font-weight: bold;text-transform: uppercase;color: #FF0000;text-align: center">Thông báo</h4>
</div>
<div class="modal-body content-popup" style="font-family: helvetica, arial, sans-serif;">
àdsafdsafdsaf
</div>
<div class="modal-footer" id="kimhung">
<!--a href="/user/withdrawruby/2?withdraw_type=1" class="btn btn-success m-btn m-btn--custom m-btn--icon m-btn--pill">Rút quà</a>-->
<button type="button" class="btn c-theme-btn c-btn-border-2x c-btn-square c-btn-bold c-btn-uppercase" data-dismiss="modal">Đóng</button>
</div>
</div>
</div>
</div>
<script>
    var width = screen.width;
    if(width <= 1000){
        alert('Màn Hình Của Bạn Không Đủ Rộng Để Sử Dụng Vòng Quay Này (Có Thể Bạn Đang Dùng Điện Thoại,Hãy Sử Dụng Máy Tính Để Sài Chức Năng Này)')
        window.location.href = "/";
    }
    $(document).ready(function(e){
        var roll_check = true;
        //Click nút quay
        $('body').delegate('#quay', 'click', function(){
            if(roll_check){
                roll_check = false;
                $.ajax({
                    url: "/ajax/nimo.php",
                    type: "POST",
                    data: { type: "nimo" },
                    dataType: "json",

                    success : function (data) {
                        if (data.status == "login") {
                            window.location.href="/dang-nhap.php";
                        }
                        else if (data.status == "success") {
                            loop(data.pos,data.phanqua);
                        }
                         else {
                            $('.content-popup').text(data.msg);
                        $('#noticeModal').modal('show');

                            roll_check = true;
                        }
                    }
                });
            }
        });

        function loop(deg,gift) {
            var items = $(".list_item").length;
            var i=0,dem=0;
            id = setInterval(function(){
                if(i == items){
                    i=0;
                    dem++;
                }
                if(dem == 5 && i == deg){
                    clearInterval(id);
                     $('.content-popup').text('Phần thưởng: '+gift);
            $('#noticeModal').modal('show');
                    roll_check = true;
                }
                var item = $(".list_item")[i];
                var pre = $(".list_item")[i-1];
                
                if(i == 0){
                    pre = $(".list_item")[items-1];
                }
                $(pre).css('background-color','');
                $(pre).css('box-shadow','');
                $(item).css('background-color','greenyellow');
                $(item).css('box-shadow','0 0 20px 1px hsla(0,0%,100%,.8)');
                i++;
            },100);
        }
    });
</script>    
<!--     <script type="text/javascript">
        $(document).ready(function(){
            $('#noticeModal').modal('show')
        });
    </script> -->
			<!-- END: PAGE CONTENT -->

	</div>
</div>
	</div>
	</div>

	</div>
	</div>
          </div>
            </div>
        </div>
    </div>

<?php
require("TMQ/end.php");
?>