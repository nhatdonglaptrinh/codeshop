<?php
	$url = 'http://sys.napthenhanh.com/api/charging-wcb'; 
	$partner_id = '909'; 
	$partner_key = 'e929a21454f12a14371681b5bbe43489'; 
?>